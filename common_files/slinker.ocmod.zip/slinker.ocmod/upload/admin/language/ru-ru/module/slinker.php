<?php
// Heading
$_['heading_title']    = 'SLinker (Линковщик сайта)';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Перелинковка сайта';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав для управления данным модулем!';